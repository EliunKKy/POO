package Hmmmmm;

public enum TipoComida {
    CHURRASQUEIRA, VEGETARIANO, ITALIANO, MARISQUEIRA
}
