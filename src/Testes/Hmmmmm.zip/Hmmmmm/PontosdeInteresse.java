package Hmmmmm;

import java.util.Collection;

public interface PontosdeInteresse {
    Collection<String> locais();
}