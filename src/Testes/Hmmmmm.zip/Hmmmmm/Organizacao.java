package Hmmmmm;

public class Organizacao {
    private String telefone;

    public Organizacao(String telefone) {
        this.telefone = telefone;
    }

    public String getTelefone() {
        return telefone;
    }

    public void setTelefone(String telefone) {
        this.telefone = telefone;
    }

}
